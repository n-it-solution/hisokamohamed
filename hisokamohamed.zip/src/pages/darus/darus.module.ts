import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DarusPage } from './darus';

@NgModule({
  declarations: [
    DarusPage,
  ],
  imports: [
    IonicPageModule.forChild(DarusPage),
  ],
})
export class DarusPageModule {}
