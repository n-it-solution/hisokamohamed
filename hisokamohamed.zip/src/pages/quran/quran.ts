import { Component } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '@angular/common/http';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {QuranAudioPage} from "../quran-audio/quran-audio";

/**
 * Generated class for the QuranPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-quran',
  templateUrl: 'quran.html',
})
export class QuranPage {
  data: Observable<any>;
  result: any;
  open(id) {
      this.navCtrl.push(QuranAudioPage,{data:id});
  }
  constructor(public navCtrl: NavController, public navParams: NavParams, public httpClient: HttpClient) {
      console.log('Quran');
    // getting data from api
      this.data = this.httpClient.get('https://nuuruliimaan.net/mobile_api/quran.php');
      this.data
          .subscribe(data => {
              console.log(data);
              this.result = data;
              // window.localStorage.result_data = JSON.stringify(data);
          },error=> {
            console.log(error)
          });
      // test data
      // console.log(JSON.parse(window.localStorage.result_data));
      // this.result = (JSON.parse(window.localStorage.result_data));
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad QuranPage');
  }

}
